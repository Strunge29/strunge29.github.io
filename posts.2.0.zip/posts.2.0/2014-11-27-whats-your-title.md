---
layout: post
title: What's your title
hide_title: true
feature-img: assets/img/pexels/story.jpeg
author: mhagnumdw
tags: [Test, Lorem]
---

This is an example of a post which includes a feature image that has a
text, where you don't want to redisplay the title.

We cannot simply set the title to the empty string, as that would
break pages that list this post, such as home and tags.



